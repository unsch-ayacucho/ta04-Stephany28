/****************************************************************
 * Ejercicio_1.java
 * @author Phany
 *
 *Escribe un programa que, dada una posici�n en un tablero de ajedrez, nos diga
a qu� casillas podr�a saltar un alfil que se encuentra en esa posici�n. Como se
indica en la figura, el alfil se mueve siempre en diagonal. El tablero cuenta con
64 casillas. Las columnas se indican con las letras de la �a� a la �h� y las filas se
indican del 1 al 8.
 *************************************************************/
import java.util.Scanner;
public class Ejercicio_3 {

	public static void main(String[] args) {
		int ubicacionFilas,ubicacionColumnas;
		int[]numeros=new int[] {8,7,6,5,4,3,2,1};
		char[] letras=new char[] {'a','b','c','d','e','f','g','h'};
		char [] [] general = new char [8][8];
		
		Scanner stdIn = new Scanner(System.in);
		System.out.println("Ingrese la fila: ");
		ubicacionFilas=stdIn.nextInt();
		while(true) {
			
			for(int i=0;i<numeros.length;i++) {
				if(ubicacionFilas==numeros[i]) {
					break;
				}
				else {
					System.out.println("Debe seleccionar un n�mero del 1 al 8: ");
					ubicacionFilas=stdIn.nextInt();
				}
			}

		}
		
		
		
	}

}